=========================
 Recovery From Failures
=========================

---------------------
 Single Node Failure
---------------------

If one of the nodes in the cluster fails, the other nodes will
continue to operate and kept up to date. When the failed node
comes up again, it automatically synchronizes with the other
nodes before it is allowed back into the cluster. No data is
lost when a node fails.   

-------------------
 Primary Component
-------------------

In addition to single node failures the cluster may be split into
several components due to network failure. A component is a set of
nodes, which are connected to each other, but not to nodes is other
components. 

.. A component is not formed until all nodes agree on the component
   membership. If consensus cannot be reached before a configurable
   timeout, the network is considered too unstable for replication.
   *What happens in this case? The entire cluster fails?*

In such a situation, only one of the components can continue to
modify the database state to avoid history divergence. This component
is called the primary component (PC). In normal operation, the Galera
cluster is a PC. When cluster partitioning happens, Galera invokes a
special quorum algorithm to select a PC that guarantees that there
is no more than one primary component in the cluster.

---------------
 Split-brain
---------------

A split-brain situation is a cluster failure where database nodes
in the cluster begin to operate autonomously from each other.
Data can get irreparably corrupted as two different database nodes
update the data independently.

Like any quorum-based system, the Galera cluster is subject to the
split-brain condition when the quorum algorithm fails to select a
primary component. This can happen, for example, in a cluster without
the backup switch if the main switch fails. However, the most likely
split-brain situation is when a single node fails in a two-node cluster.
Thus it is strongly advised that the minimum Galera cluster
configuration is three nodes.

------------------------
 State Transfer Failure
------------------------

A failure in state transfer renders the receiving node unusable.
If a state transfer failure is detected, the receiving node will
abort.

Restarting the node after a mysqldump failure may require manual
restoring of the administrative tables. The rsync method does not
have this issue, since it does not need the server to be in
operational state.
