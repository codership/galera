===================
 Galera Parameters
===================
As of version 0.8 Galera accepts parameters as semicolon-separated
key value pair lists, such as ``key1 = value1; key2 = value2``.
In this way, you can configure an arbitrary number of Galera parameters
in one call. A key consists of parameter group and parameter name:

``<group>.<name>``

Where ``<group>`` roughly corresponds to some Galera module.

Table legend:

- *Numeric values* |---| Galera understand the following numeric modifiers:
  K, M, G, T standing for |210|, |220|, |230| and |240| respectively.
- *Boolean values* |---| Galera accepts the following boolean values: 0, 1, yes, no, true, false, on, off.
- Time periods must be expressed in the ISO8601 format. See also the examples below.
- ``(R)`` marks parameters that can be changed during runtime.

.. |210| replace:: 2\ :sup:`10`\
.. |220| replace:: 2\ :sup:`20`\
.. |230| replace:: 2\ :sup:`30`\
.. |240| replace:: 2\ :sup:`40`\

A test on documenting options in a table:

+---------------------------------------+-----------------------+----------------------------------------------------+
| Parameter                             | Default               | Description                                        |
+=======================================+=======================+====================================================+
| ``protonet.backend``                  | asio                  | Which transport backend to use. Currently only     |
|                                       |                       | ASIO is supported.                                 |
+---------------------------------------+-----------------------+----------------------------------------------------+
| ``protonet.version``                  | 0                     |                                                    |
+---------------------------------------+-----------------------+----------------------------------------------------+
| ``socket.ssl_cert``                   |                       | A path (absolute or relative to the working dir)   |
|                                       |                       | to an SSL certificate (in PEM format).             |
+---------------------------------------+-----------------------+----------------------------------------------------+
| ``socket.ssl_key``                    |                       | A path (absolute or relative to the working dir) to|
|                                       |                       | a private key for a certificate (in PEM format).   |
+---------------------------------------+-----------------------+----------------------------------------------------+
|                                       |                       |                                                    |
+---------------------------------------+-----------------------+----------------------------------------------------+

A test on documenting options in man page style:

``wsrep_notify_cmd``

This command is run whenever the cluster membership or state
of this node changes. This option can be used to (re)configure
load balancers, raise alarms, and so on. The command passes on
one or more of the following options:

--status <status str>        The status of this node. The possible statuses are:

                            - *Undefined* |---| The node has just started up 
                              and is not connected to any primary component
                            - *Joiner* |---| The node is connected to a primary
                              component and now is receiving state snapshot.
                            - *Donor* |---| The node is connected to primary
                              component and now is sending state snapshot.
                            - *Joined* |---| The node has a complete state and
                              now is catching up with the cluster.  
                            - *Synced* |---| The node has synchronized itself
                              with the cluster.
                            - *Error(<error code if available>)* |---| The node
                              is in an error state.
                                
--uuid <state UUID>            The cluster state UUID.
--primary <yes/no>            Whether the current cluster component is primary or not.
--members <list>            A comma-separated list of the component member UUIDs.
                            The members are presented in the following syntax: 
                            
                            - ``<node UUID>`` |---| A unique node ID. The wsrep
                              provider automatically assigns tjhis ID for each node.
                            - ``<node name>`` |---| The node name as it is set in the
                              ``wsrep_node_name`` option.
                            - ``<incoming address>`` |---| The address for client
                              connections as it is set in the ``wsrep_node_incoming_address``
                              option.

.. |---|   unicode:: U+2014 .. EM DASH
   :trim:
   
