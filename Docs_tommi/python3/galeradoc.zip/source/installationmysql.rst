====================================
 Installing Galera Cluster on MySQL
====================================

If you have decided to install Galera on a MySQL Cluster,
proceed as follows:

1. Download the Galera Cluster (https://launchpad.net/galera/+download).
2. Install the Galera Cluster.
