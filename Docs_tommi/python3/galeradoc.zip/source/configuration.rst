=============================
 Configuring Galera Cluster
=============================

This chapter presents the mandatory and recommended settings
for a Galera cluster. For more information on the settings,
see chapter Reference.

--------------------
 Mandatory Settings
--------------------
You must give values to the settings below:

- ``wsrep_provider`` |---| The path to the Galera plugin.
- ``wsrep_cluster_address`` |---| The cluster connection URL.
  See chapter :ref:`creating-a-cluster`.
- ``binlog_format=ROW``
- ``default_storage_engine=InnoDB``
- ``innodb_autoinc_lock_mode=2``
- ``innodb_locks_unsafe_for_binlog=1``

   .. note:: If you use Galera provider version 2.0 or higher,
             set ``innodb_doublewrite`` to 1 (default).

--------------------
 Optional Settings
--------------------

For better performance, you can adjust the
``innodb_flush_log_at_trx_commit`` parameter value. This value
defines how often the log buffer is written out to the log
file and how often the log file is flushed onto disk. When
the value is 2, the log buffer is written out to the file at
each commit, but the flush to disk operation is not performed
on it, but it takes place once per second. 

Compared with the default value 1, you can achieve better
performance by setting the value to 2, but an operating system
crash or a power outage can erase the last second of transactions.
However, this risk is handled by synchronous replication |---| you
can always recover the node from another node.

Set:

``innodb_flush_log_at_trx_commit=2``

------------------
 Memory Settings
------------------

During normal operation a MariaDB Galera node does not consume
much more memory than a regular MariaDB server. Additional
memory is consumed for the certification index and uncommitted
write sets, but usually this is not noticeable in a typical
application. However, writeset caching during state transfer
makes an exception.

When a node is receiving a state transfer, it cannot process
and apply incoming write sets because it has no state to
apply them to yet. Depending on a state transfer mechanism
(for example, *mysqldump*), the node that sends the state
transfer may not be able to apply write sets. Instead, the
node must cache the write sets for a catch-up phase. Currently,
the write sets are cached in memory and, if the system runs out
of memory, either the state transfer will fail or the cluster
will block and wait for the state transfer to end.

To control memory usage for writeset caching, adjust the
Galera parameters below:

- ``gcs.recv_q_hard_limit``
- ``gcs.recv_q_soft_limit``
- ``gcs.max_throttle``

 
.. |---|   unicode:: U+2014 .. EM DASH
   :trim:
